var DEMO_APPS = {
  "qa": {
    endpoints: {
      api: "api.quickblox.com",
      chat: "chat.quickblox.com"
    },
    credentials: {
      'appId': 72448,
      'authKey': 'f4HYBYdeqTZ7KNb',
      'authSecret': 'ZC7dK39bOjVc-Z8'
    },
    demoChatDialogId: ""
  },
  "VideoRecordingDemoApp1": {
    endpoints: {
      api: "apirc.quickblox.com",
      chat: "chatrc.quickblox.com"
    },
    credentials: {
      'appId': 67897,
      'authKey': 'JEMb6GKcrrzOBTP',
      'authSecret': 'h2UxCPHf7Oqk8Pw'
    },
    demoChatDialogId: "5afa823c12685f101adaf628"
  },
  "VideoRecordingDemoApp2": {
    endpoints: {
      api: "apirc.quickblox.com",
      chat: "chatrc.quickblox.com"
    },
    credentials: {
      'appId': 67898,
      'authKey': 'kAgbhA9Q99UtygB',
      'authSecret': 'DxgzQyyOgaYaLJL'
    },
    demoChatDialogId: "5afa825512685f101adaf62a"
  }
}

export class LoginModel {
  userName: string;
  userLogin: string;
}
